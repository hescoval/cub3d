# SimonKraft Textures

These textures are part of the SimonKraft Minecraft texture pack. It is available in full at [planetminecraft.com](https://www.planetminecraft.com/texture-pack/simonkraft/).
